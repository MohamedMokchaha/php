<?php

require('connect.php');

 
  $code_prod = $_POST['code_prod'];
  $email = $_POST['email'];
  $tel = $_POST['tel'];
  $msg = $_POST['msg'];

$insertion = ("INSERT INTO declaration(code_prod, email, tel, msg) VALUES ('$code_prod', '$email', '$tel', '$msg')");

$execute = $pdo->query($insertion);

if($execute == true){$msgSuccess = "Informations enregistrées avec succés";}
else
{$msgError = "L'enregistrement n'a pas pu être effectué ";}




?>
<div>
<?php
if(isset($msgError)){echo $msgError;} 
elseif 
  (isset($msgSuccess)) {echo $msgSuccess;}
?>

</div>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Declaration</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">


  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">


  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

 
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">

 
  <link href="css/style.css" rel="stylesheet">


</head>

<body >

  <div id="h">
    <div class="logo">SumoLanding</div>
    <div class="social hidden-xs">
      <a href="https://twitter.com/lestechnos"><i class="ion-social-twitter"></i></a>
      <a href="https://www.instagram.com/explore/locations/358192574664427/technoss/?hl=fr"><i class="ion-social-instagram"></i></a>
      <a href="https://fr-fr.facebook.com/Technosssinformatique"><i class="ion-social-facebook"></i></a>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 centered">
          <h1 style=font-family:"Comic Sans MS";><br/> Usually we are at your service</h1>
          <div class="mtb">
            <form role="form" action="declaration.php" method="post" >

              <table>
<tr>

             <td> <input type="texte" name="code_prod"  placeholder="code produit..." required></td>
                                                                                                                                     <td><p >............</p></td>


           <td rowspan="3">   <input type="texte" name="msg" class="msg" size="90"  placeholder="Déclaration..." required></td></tr>

        <tr><td>   <input type="email" name="email"  placeholder="Adresse e-mail..." required><td></tr>

             <tr><td>  <input type="texte" name="tel"  placeholder="Tel ..." pattern="[0-9]{8}" required></td></tr>


              

              </table>




              <button class='btn btn-conf btn-green' type="submit"> Envoyer la déclaration  </button>
            </form>
          </div>
     
          <h4>Contacter - nous .</h4>
        </div>
      </div>
    
    </div>
  
  </div>


  <div class="container ptb">
    <div class="row">
      <div class="col-md-6">
        <h2>Toutes les fonctionnalités que vous souhaitez dans ce type d'applications, vous les trouverez ici</h2>
        <p class="mt"> retrouvez toutes les informations (présentation, téléphone, fax, mail, adresse, catalogue) de TECHNOSS INFORMATIQUE sur votre Annuaire. .</p>
        <p class="store">
          <a href="#"><img src="img/app-store.png" height="50" alt=""></a>
          <a href="#"><img src="img/google-play.png" height="50" alt=""></a>
        </p>
      </div>
      <div class="col-md-6">
        <img src="img/phone.png" class="img-responsive mt" alt="">
      </div>
    </div>
    <!--/row-->
  </div>
  <!--/container-->

  <div id="sep">
    <div class="container">
      <div class="row centered">
        <div class="col-md-8 col-md-offset-2">
          <h1>Rejoignez vos expériences avec les personnes qui vous intéressent le plus. Laissez-nous vous aider</h1>
          <h4>Toutes ces pannes vont immobiliser l'activité d'une société tant qu'elles ne seront pas réparées... et c'est là que toute la puissance d'une société de maintenance informatique intervient !</h4>
          
        </div>
        <!--/col-md-8-->
      </div>
    </div>
  </div>
  <!--/sep-->


  <script src="js/main.js"></script>

</body>
</html>
