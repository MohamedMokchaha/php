<?php

$pdo = null;


$pdo= new PDO('mysql:host=localhost;dbname=stage', 'root', '');

?>